#ifndef __LED_H__
#define __LED_H__
#define GPIOA_BASE_ADDR 0x40020000
#define GPIOB_BASE_ADDR 0x40020400
#define GPIOC_BASE_ADDR 0x40020800
#define GPIOD_BASE_ADDR 0x40020C00
#define GPIOE_BASE_ADDR 0x40021000
#define GPIOF_BASE_ADDR 0x40021400
#define GPIOG_BASE_ADDR 0x40021800
#define GPIOH_BASE_ADDR 0x40021C00
#define GPIOI_BASE_ADDR 0x40022000

#define MODER_OFFSET_ADDR  0x00
#define OTYPER_OFFSET_ADDR  0x04
#define OSPEEDR_OFFSET_ADDR  0x08
#define PUPDR_OFFSET_ADDR  0x0C
#define IDR_OFFSET_ADDR  0x10
#define ODR_OFFSET_ADDR  0x14
#define BSRR_OFFSET_ADDR  0x18
#define ATRL_OFFSET_ADDR  0x20
#define ATRH_OFFSET_ADDR  0x24

#define GPIOH_MODER (*(volatile unsigned long*)(GPIOA_BASE_ADDR+MODER_OFFSET_ADDR))
#define GPIOH_OTYPER (*(volatile unsigned long*)(GPIOA_BASE_ADDR+OTYPER_OFFSET_ADDR))
#define GPIOH_OSPEEDR (*(volatile unsigned long*)(GPIOA_BASE_ADDR+OSPEEDR_OFFSET_ADDR))
#define GPIOH_ODR (*(volatile unsigned long*)(GPIOA_BASE_ADDR+ODR_OFFSET_ADDR))
#define GPIOH_BSRR (*(volatile unsigned long*)(GPIOA_BASE_ADDR+BSRR_OFFSET_ADDR))
	
#define RCC_APB2ENR (*(volatile unsigned long*)(0x40010018))
	
enum LED_NUM{LED0,LED1};
enum LED_STATE{LED_ON,LED_OFF};

#endif

