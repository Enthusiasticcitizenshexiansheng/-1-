#include "led.h"

void led_init(void)
	//pB5 PE5
{
	
	RCC_APB2ENR |= (1<<3);
	
	GPIOH_MODER &= ~(0x3F<<20);//λ���
	GPIOH_MODER |= 0x15;//����Ϊ 010101
	

	GPIOH_OTYPER  |= 0x07<<10; 
	
//����
	GPIOH_OSPEEDR &=~(0x3F<<20);

	//Ĭ��״̬
   GPIOH_ODR |= 0x07<<10; //111  �ߵ�ƽ Ϩ��

}


void led_ctrl(int led_num,int led_state)
{
	switch(led_num)
	{
 
		 case LED0:
    	GPIOH_BSRR |=1<<(16*!led_state+10);break;	
		  case LED1:
    	GPIOH_BSRR |=1<<(16*!led_state+11);break;
//			 case LED2:
//    	GPIOH_BSRR |=1<<(16*!led_state+12);break;
}
}
int main()
{led_init();
	led_ctrl(LED0,LED_ON);
	led_ctrl(LED1,LED_ON);
//	led_ctrl(LED2,LED_ON);

	while(1);
	
}


